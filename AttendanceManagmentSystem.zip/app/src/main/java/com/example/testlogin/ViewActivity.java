package com.example.testlogin;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class ViewActivity extends AppCompatActivity {

    Cursor cursor;
    String value,emailstring,selected;
    SQLiteOpenHelper openHelper;
    SQLiteDatabase db;
    ListView listview;
    List<String> list = new ArrayList<String>();
    AlertDialog.Builder builder;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);

        Intent intent = getIntent();
        emailstring = intent.getStringExtra("email2");
        value = emailstring;
        openHelper = new DatabaseHelper(this);
        db=openHelper.getReadableDatabase();
        cursor = db.rawQuery("SELECT CourseName FROM RegisterCourse WHERE F_Email=?", new String[]{value});
        //if (cursor!=null && cursor.getCount()!=0) {
            while (cursor.moveToNext()) {
                String name1 = "";
                name1 = cursor.getString(cursor.getColumnIndex("CourseName"));
                list.add(name1);
                adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
                listview = findViewById(R.id.listView);
                listview.setAdapter(adapter);
                //list.clear();
            }
        //}
       // else {
            if (cursor.getCount() == 0 || cursor == null) {
                Toast.makeText(this, "No Data to Show", Toast.LENGTH_SHORT).show();
            }
        //}
        registerForContextMenu(listview);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //cursor.requery();
                String text = listview.getItemAtPosition(i).toString();
                Toast.makeText(getApplicationContext(), ""+text, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(ViewActivity.this, ViewClassActivity.class);
                intent.putExtra("value", text);
                startActivity(intent);
            }
        });
        //cursor.close();
    }

    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {

        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.menu1, menu);

    }
    public boolean onContextItemSelected(MenuItem item) {

        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();

        switch (item.getItemId()) {
            case R.id.edit:
                selected=list.get(info.position);
                Intent intent =new Intent(ViewActivity.this,EditCourseActivity.class);
                intent.putExtra("name",selected);
                startActivityForResult(intent,1);
                return true;

            case R.id.delete:
                selected=list.get(info.position);
                builder.setMessage("Do you want to delete this country ?")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                db = openHelper.getWritableDatabase();
                                cursor = db.rawQuery("SELECT * FROM RegisterCourse WHERE CourseName=?", new String[]{selected});
                                while (cursor.moveToNext()) {
                                    String whereClause = selected;
                                    db.delete("RegisterCourse","selected",null);
                                }
                                /*for(int i=0;i<countries.length-1;i++)
                                {
                                    if (selected.equals(countries[i].getName()))
                                    {
                                        list.remove(i);
                                        adapter.notifyDataSetChanged();
                                    }
                                    adapter.notifyDataSetChanged();
                                }
                            }*/
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //  Action for 'NO' Button
                                dialog.cancel();
                            }
                        });
                //Creating dialog box
                AlertDialog alert = builder.create();
                alert.show();
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }

    /*public void viewCourse()
    {
        openHelper = new DatabaseHelper(this);
        db=openHelper.getReadableDatabase();
        cursor = db.rawQuery("SELECT CourseName FROM RegisterCourse",null);
        if (cursor.getCount() == 0)
        {
            Toast.makeText(getApplicationContext(), "No Data to Show", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(getApplicationContext(), "No Data to Show", Toast.LENGTH_SHORT).show();
            if (cursor!=null) {
                while (cursor.moveToNext()) {
                    String name1 = cursor.getString(1);
                    list.add(name1);
                    adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
                    listview = findViewById(R.id.listView);
                    listview.setAdapter(adapter);
               }
            }
        }
    }*/
}
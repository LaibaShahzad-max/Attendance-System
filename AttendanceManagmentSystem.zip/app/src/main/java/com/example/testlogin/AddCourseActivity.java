package com.example.testlogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddCourseActivity extends AppCompatActivity {

    SQLiteOpenHelper openHelper ;
    SQLiteDatabase db;
    Button submit;
    EditText et1, et2, et3;
    String email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_course);

        Intent intent = getIntent();
        email = intent.getStringExtra("email1");

        openHelper= new DatabaseHelper(this);
        submit=(Button)findViewById(R.id.submitbutton);
        et1=(EditText)findViewById(R.id.course1);
        et2=(EditText)findViewById(R.id.class1);
        et3=(EditText)findViewById(R.id.section1);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                db=openHelper.getWritableDatabase();
                String emailstr = email;
                String coursestr=et1.getText().toString();
                String classstr=et2.getText().toString();
                String sectionstr=et3.getText().toString();
                /*if((sectionstr.charAt(0)!='A') || (sectionstr.charAt(0)!='B') || (sectionstr.charAt(0)!='C') || (sectionstr.charAt(0)!='D')
                        || (sectionstr.charAt(0)!='E') || (sectionstr.charAt(0)!='F') || (sectionstr.charAt(0)!='G') || (sectionstr.charAt(0)!='H')
                        || (sectionstr.charAt(0)!='I') || (sectionstr.charAt(0)!='J') || (sectionstr.charAt(0)!='K') || (sectionstr.charAt(0)!='L')
                        || (sectionstr.charAt(0)!='M') || (sectionstr.charAt(0)!='N') || (sectionstr.charAt(0)!='O') || (sectionstr.charAt(0)!='P')
                        || (sectionstr.charAt(0)!='P') || (sectionstr.charAt(0)!='Q') || (sectionstr.charAt(0)!='R') || (sectionstr.charAt(0)!='S')
                        || (sectionstr.charAt(0)!='T') || (sectionstr.charAt(0)!='U') || (sectionstr.charAt(0)!='V') || (sectionstr.charAt(0)!='W')
                        || (sectionstr.charAt(0)!='X') || (sectionstr.charAt(0)!='Y') || (sectionstr.charAt(0)!='Z'))
                {
                    Toast.makeText(getApplicationContext(), "Enter Valid Section", Toast.LENGTH_LONG).show();
                    return;
                }*/

                insertcoursedata(emailstr, coursestr,classstr,sectionstr);
                Toast.makeText(getApplicationContext(),"Course Added Successfully", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(AddCourseActivity.this, ViewActivity.class);
                intent.putExtra("email2", emailstr);
                startActivity(intent);
            }
        });
    }

    public void insertcoursedata(String emailstr, String coursestr, String classstr, String sectionstr)
    {
        ContentValues ContentValues= new ContentValues();
        ContentValues.put(DatabaseHelper.COLL_2, emailstr);
        ContentValues.put(DatabaseHelper.COLL_3, coursestr);
        ContentValues.put(DatabaseHelper.COLL_4, classstr);
        ContentValues.put(DatabaseHelper.COLL_5, sectionstr);

        long id=db.insert(DatabaseHelper.TABLE_NAME1,null,ContentValues);
    }
}
package com.example.testlogin;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.util.Calendar;

public class ViewAttendanceActivity extends AppCompatActivity implements View.OnClickListener {

    EditText ed0,ed1,ed2,ed3,ed4,ed5,ed6,ed7,ed8,ed9,ed10,ed11,ed12,ed13,ed14,ed15,ed16,ed17,ed18,ed19,ed20,ed21,ed22,ed23,ed24,ed25,ed26,ed27,ed28,ed29,ed30,ename1,ename2,ename3,ename4,ename5,ereg1,ereg2,ereg3,ereg4,ereg5;
    TextView tcourse,tclass;
    Button b1;
    private int mYear, mMonth, mDay;
    int count=5;
    SQLiteOpenHelper openHelper;
    SQLiteDatabase db;
    String str1,str2,course,s_class,section,date;
    String[] namestr = new String[5];
    String[] regstr = new String[5];
    int colIndex = 0;
    private GridLayout gridLayout;
    Cursor cursor;
    //gridLayout = (GridLayout) findViewById(R.id.inputTasksLayout);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_attendance);

        openHelper = new DatabaseHelper(this);
        /*cursor = db.rawQuery("SELECT * FROM Attendance", null);
        while(cursor.moveToNext())
        {
            String getname1 = cursor.getString(cursor.getColumnIndex("Student_Name"));
            String getreg1 =  cursor.getString(cursor.getColumnIndex("Student_Reg"));
            String getdate1 =  cursor.getString(cursor.getColumnIndex("Date"));
        }*/

        gridLayout = (GridLayout) findViewById(R.id.inputTasksLayout);

        Intent intent = getIntent();
        str1 = intent.getStringExtra("course");
        str2 = intent.getStringExtra("class-section");
        course = str1;
        String[] str4 = str2.split(":");
        for(int i=0; i<1; i++)
        {
            s_class = str4[0];
            section = str4[1];

        }

        tcourse = findViewById(R.id.tcourse);
        tcourse.setText(str1+"  ");

        tclass = findViewById(R.id.tclass);
        tclass.setText(str2+"  ");

        ename1 = findViewById(R.id.name1);
        ename2 = findViewById(R.id.name2);
        ename3 = findViewById(R.id.name3);
        ename4 = findViewById(R.id.name4);
        ename5 = findViewById(R.id.name5);

        ereg1 = findViewById(R.id.reg1);
        ereg2 = findViewById(R.id.reg2);
        ereg3 = findViewById(R.id.reg3);
        ereg4 = findViewById(R.id.reg4);
        ereg5 = findViewById(R.id.reg5);

        b1 = findViewById(R.id.savebutton);
        b1.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                db = openHelper.getWritableDatabase();

                String name1 = ename1.getText().toString();
                String name2 = ename2.getText().toString();
                String name3 = ename3.getText().toString();
                String name4 = ename4.getText().toString();
                String name5 = ename5.getText().toString();


                String reg1 = ereg1.getText().toString();
                String reg2 = ereg2.getText().toString();
                String reg3 = ereg3.getText().toString();
                String reg4 = ereg4.getText().toString();
                String reg5 = ereg5.getText().toString();

                String date1 = ed0.getText().toString();
                String date2 = ed1.getText().toString();
                String date3 = ed2.getText().toString();
                String date4 = ed3.getText().toString();
                String date5 = ed4.getText().toString();

                insert(name1, reg1, date1);
                insert(name2, reg2, date2);
                insert(name3, reg3, date3);
                insert(name4, reg4, date4);
                insert(name5, reg5, date5);

                Toast.makeText(getApplicationContext(),"Attendance Saved", Toast.LENGTH_LONG).show();
            }
         });

        ed0 = findViewById(R.id.l0);
        ed0.setOnClickListener(this);
        ed1 = findViewById(R.id.l1);
        ed1.setOnClickListener(this);
        ed2 = findViewById(R.id.l2);
        ed2.setOnClickListener(this);
        ed3 = findViewById(R.id.l3);
        ed3.setOnClickListener(this);
        ed4 = findViewById(R.id.l4);
        ed4.setOnClickListener(this);
        ed5 = findViewById(R.id.l5);
        ed5.setOnClickListener(this);
        ed6 = findViewById(R.id.l6);
        ed6.setOnClickListener(this);
        ed7 = findViewById(R.id.l7);
        ed7.setOnClickListener(this);
        ed8 = findViewById(R.id.l8);
        ed8.setOnClickListener(this);
        ed9 = findViewById(R.id.l9);
        ed9.setOnClickListener(this);
        ed10 = findViewById(R.id.l10);
        ed10.setOnClickListener(this);
        ed11 = findViewById(R.id.l11);
        ed11.setOnClickListener(this);
        ed12 = findViewById(R.id.l12);
        ed12.setOnClickListener(this);
        ed13 = findViewById(R.id.l13);
        ed13.setOnClickListener(this);
        ed14 = findViewById(R.id.l14);
        ed14.setOnClickListener(this);
        ed15 = findViewById(R.id.l15);
        ed15.setOnClickListener(this);
        ed16 = findViewById(R.id.l16);
        ed16.setOnClickListener(this);
        ed17 = findViewById(R.id.l17);
        ed17.setOnClickListener(this);
        ed18 = findViewById(R.id.l18);
        ed18.setOnClickListener(this);
        ed19 = findViewById(R.id.l19);
        ed19.setOnClickListener(this);
        ed20 = findViewById(R.id.l20);
        ed20.setOnClickListener(this);
        ed21 = findViewById(R.id.l21);
        ed21.setOnClickListener(this);
        ed22 = findViewById(R.id.l22);
        ed22.setOnClickListener(this);
        ed23 = findViewById(R.id.l23);
        ed23.setOnClickListener(this);
        ed24 = findViewById(R.id.l24);
        ed24.setOnClickListener(this);
        ed25 = findViewById(R.id.l25);
        ed25.setOnClickListener(this);
        ed26 = findViewById(R.id.l26);
        ed26.setOnClickListener(this);
        ed27 = findViewById(R.id.l27);
        ed27.setOnClickListener(this);
        ed28 = findViewById(R.id.l28);
        ed28.setOnClickListener(this);
        ed29 = findViewById(R.id.l29);
        ed29.setOnClickListener(this);
        ed30 = findViewById(R.id.l30);
        ed30.setOnClickListener(this);


    }


    int rowIndex = 7;
    public void addView(View view) {
        EditText editText = new EditText(this);
        GridLayout.LayoutParams param = new GridLayout.LayoutParams();
        param.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        param.width = GridLayout.LayoutParams.MATCH_PARENT;
        param.rowSpec = GridLayout.spec(rowIndex);
        param.columnSpec = GridLayout.spec(colIndex);
        editText.setLayoutParams(param);
        int rowcount = rowIndex-1;
        editText.setHint("name " + rowcount);
        int rowId = this.getResources().getIdentifier("row_"+rowIndex, "string", this.getPackageName());
        editText.setId(rowId);

        EditText editText1 = new EditText(this);
        GridLayout.LayoutParams param1 = new GridLayout.LayoutParams();
        param1.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        param1.width = GridLayout.LayoutParams.MATCH_PARENT;
        param1.rowSpec = GridLayout.spec(rowIndex);
        param1.columnSpec = GridLayout.spec(colIndex);
        editText.setLayoutParams(param1);
        editText1.setHint("reg "+ rowcount);

        gridLayout.addView(editText);
        gridLayout.addView(editText1);
        gridLayout.addView(addtoggle(view));
        gridLayout.addView(addtoggle(view));
        gridLayout.addView(addtoggle(view));
        gridLayout.addView(addtoggle(view));
        gridLayout.addView(addtoggle(view));
        gridLayout.addView(addtoggle(view));
        gridLayout.addView(addtoggle(view));
        gridLayout.addView(addtoggle(view));
        gridLayout.addView(addtoggle(view));
        gridLayout.addView(addtoggle(view));
        gridLayout.addView(addtoggle(view));
        gridLayout.addView(addtoggle(view));
        gridLayout.addView(addtoggle(view));
        gridLayout.addView(addtoggle(view));
        gridLayout.addView(addtoggle(view));
        gridLayout.addView(addtoggle(view));
        gridLayout.addView(addtoggle(view));
        gridLayout.addView(addtoggle(view));
        gridLayout.addView(addtoggle(view));
        gridLayout.addView(addtoggle(view));
        gridLayout.addView(addtoggle(view));
        gridLayout.addView(addtoggle(view));
        gridLayout.addView(addtoggle(view));
        gridLayout.addView(addtoggle(view));
        gridLayout.addView(addtoggle(view));
        gridLayout.addView(addtoggle(view));
        gridLayout.addView(addtoggle(view));
        gridLayout.addView(addtoggle(view));
        gridLayout.addView(addtoggle(view));
        gridLayout.addView(addtoggle(view));
        rowIndex++;
        colIndex=0;
    }

    public View addtoggle(View view ) {

        ToggleButton tb = new ToggleButton(this);
        GridLayout.LayoutParams param2 = new GridLayout.LayoutParams();
        param2.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        param2.width = GridLayout.LayoutParams.WRAP_CONTENT;
        param2.rowSpec = GridLayout.spec(rowIndex);
        param2.columnSpec = GridLayout.spec(colIndex+2);
        tb.setText("A");
        tb.setLayoutParams(param2);
        tb.setTextOff("A");
        tb.setTextOn("P");
        colIndex++;
        return tb;
    }

    public void insert(String namestr,String regstr,String datestr) {
        ContentValues ContentValues= new ContentValues();
        ContentValues.put(DatabaseHelper.COLLL_2, namestr);
        ContentValues.put(DatabaseHelper.COLLL_3, regstr);
        ContentValues.put(DatabaseHelper.COLLL_4, datestr);

        long id=db.insert(DatabaseHelper.TABLE_NAME,null,ContentValues);
    }
    public void insertattendance(String getname, String getreg, String getcourse, String gets_class, String getsection,String getdate)
    {
        for(int i=0; i<=5; i++)
        {
            String name1[] = new String[5];
            name1[i] = getname;
            String name = name1[i];
            ContentValues ContentValues= new ContentValues();
            ContentValues.put(DatabaseHelper.COLLLL_2, name);
            ContentValues.put(DatabaseHelper.COLLL_2, name);
            ContentValues.put(DatabaseHelper.COLLL_3, getdate);
            ContentValues.put(DatabaseHelper.COLLLL_5, getcourse);
            ContentValues.put(DatabaseHelper.COLLLL_6, gets_class);
            ContentValues.put(DatabaseHelper.COLLLL_7, getsection);

            long id=db.insert(DatabaseHelper.TABLE_NAME,null,ContentValues);
        }
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu2, menu);
        return true;

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        // Handle item selection
        switch (item.getItemId())
        {
            case R.id.add:
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onClick(View view) {
        count++;
        if (view == ed0)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed0.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
    }
        if(view == ed1)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed1.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if(view == ed2)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed2.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if(view == ed3)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed3.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if (view == ed4)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed4.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if(view == ed5)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed5.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if(view == ed6)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed6.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if(view == ed7)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed7.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if(view == ed8)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed8.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if(view == ed9)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed9.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if(view == ed10)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed10.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if(view == ed11)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed11.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if(view == ed12)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed12.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if(view == ed13)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed13.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if(view == ed14)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed14.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if(view == ed15)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed15.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if(view == ed16)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed16.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if(view == ed17)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed17.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if(view == ed18)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed18.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if(view == ed19)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed19.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if(view == ed20)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed20.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if(view == ed21)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed21.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if(view == ed22)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed22.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if(view == ed23)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed23.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if(view == ed24)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed24.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if(view == ed25)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed25.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if(view == ed26)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed26.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if(view == ed27)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed27.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if(view == ed28)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed28.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if(view == ed29)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed29.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if(view == ed30)
        {
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            ed30.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
    }

    public void onToggleClicked(View view) {
        // Is the toggle on?
        boolean on = ((ToggleButton) view).isChecked();

        if (on) {
            // Enable vibrate
        } else {
            // Disable vibrate
        }
    }

}

package com.example.testlogin;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class ViewClassActivity extends AppCompatActivity {

    SQLiteOpenHelper openHelper;
    SQLiteDatabase db;
    String value1,value2,value3;
    Cursor cursor;
    ListView listview;
    List<String> list = new ArrayList<String>();
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_class);

        openHelper = new DatabaseHelper(this);
        db=openHelper.getReadableDatabase();
        Intent intent = getIntent();
        value1 = intent.getStringExtra("value");
        value3 = value1;
        cursor = db.rawQuery("SELECT Class, Section FROM RegisterCourse WHERE CourseName=?",new String[]{value3});
        while (cursor.moveToNext()) {
            String name2 = "";
            String name3 = "";
            name2 = cursor.getString(cursor.getColumnIndex("Class"));
            name3 = cursor.getString(cursor.getColumnIndex("Section"));
            list.add(name2 + ": " + name3);
            adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
            listview = findViewById(R.id.listView1);
            listview.setAdapter(adapter);
        }

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //cursor.requery();
                value2 = listview.getItemAtPosition(i).toString();
                Toast.makeText(getApplicationContext(), ""+value2, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(ViewClassActivity.this, ViewAttendanceActivity.class);
                intent.putExtra("class-section", value2);
                intent.putExtra("course", value1);
                startActivity(intent);
            }
        });
        cursor.close();
    }
}
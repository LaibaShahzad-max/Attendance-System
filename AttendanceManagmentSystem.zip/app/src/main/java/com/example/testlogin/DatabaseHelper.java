package com.example.testlogin;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME="register.db";
    public static final String TABLE_NAME="Faculty";
    public static final String COL_1="ID";
    public static final String COL_2="FirstName";
    public static final String COL_3="LastName";
    public static final String COL_4="Password";
    public static final String COL_5="Email";
    public static final String COL_6="Phone";

    public static final String TABLE_NAME1="RegisterCourse";
    public static final String COLL_1="ID";
    public static final String COLL_2="F_Email";
    public static final String COLL_3="CourseName";
    public static final String COLL_4="Class";
    public static final String COLL_5="Section";

    public static final String TABLE_NAME2="Attendance";
    public static final String COLLL_1="ID";
    public static final String COLLL_2="Student_Name";
    public static final String COLLL_3="Student_Reg";
    public static final String COLLL_4="Date";

    public static final String TABLE_NAME3="Student";
    public static final String COLLLL_1="Student_ID";
    public static final String COLLLL_2="Student_Name";
    public static final String COLLLL_3="Student_Reg";
    public static final String COLLLL_4="A_Email";
    public static final String COLLLL_5="A_CourseName";
    public static final String COLLLL_6="A_Class";
    public static final String COLLLL_7="A_Section";
    public static final String COLLLL_8="Total_Attendance";


    public DatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE Faculty(ID INTEGER PRIMARY KEY AUTOINCREMENT,FirstName TEXT,LastName TEXT,Password Text,Email Text,Phone TEXT)");
        db.execSQL("CREATE TABLE RegisterCourse(ID INTEGER PRIMARY KEY AUTOINCREMENT,F_Email TEXT,CourseName TEXT,Class Text,Section Text)");
        db.execSQL("CREATE TABLE Attendance(ID INTEGER PRIMARY KEY AUTOINCREMENT,Student_ID TEXT,Date TEXT)");
        db.execSQL("CREATE TABLE Student(ID INTEGER PRIMARY KEY AUTOINCREMENT,Student_ID TEXT,Student_Name TEXT,Student_Reg TEXT,A_Emil Text,A_CourseName Text,A_Class TEXT,A_Section TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS Faculty");
        onCreate(db);
    }
}

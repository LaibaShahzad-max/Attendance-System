package com.example.testlogin;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MenuActivity extends AppCompatActivity {

    Button btnadd, btnview, btnlogout,btnhelp;
    DatabaseHelper dbHelper;
    SQLiteDatabase db;
    String getemail,em1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        dbHelper = new DatabaseHelper(this);
        db = dbHelper.getReadableDatabase();

        Intent intent = getIntent();
        getemail = intent.getStringExtra("email");
        em1 = getemail;

        btnadd = (Button) findViewById(R.id.buttonadd);
        btnview = (Button) findViewById(R.id.buttonview);
        btnlogout = (Button) findViewById(R.id.buttonlogout);
        btnhelp = (Button) findViewById(R.id.buttonhelp);


        btnadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MenuActivity.this, AddCourseActivity.class);
                intent.putExtra("email1", em1);
                startActivity(intent);
                Toast.makeText(getApplicationContext(), "Add Course", Toast.LENGTH_SHORT).show();
            }
        });

        btnview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                        Intent intent = new Intent(MenuActivity.this, ViewActivity.class);
                        intent.putExtra("email2", em1);
                        startActivity(intent);
                        Toast.makeText(getApplicationContext(), "View Course", Toast.LENGTH_SHORT).show();
            }
        });

        btnlogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MenuActivity.this, LoginActivity.class);
                startActivity(intent);
                Toast.makeText(getApplicationContext(), "Logout successful", Toast.LENGTH_SHORT).show();
            }
        });

        btnhelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://developer.android.com/";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
                Toast.makeText(getApplicationContext(), "GOOGLE", Toast.LENGTH_SHORT).show();
            }
        });
    }
}